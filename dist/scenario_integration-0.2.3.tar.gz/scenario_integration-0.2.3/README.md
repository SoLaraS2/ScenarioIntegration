# ScenarioIntegration
Modeling tool now as a python package
Notebook-first API for your Scenario Integration workflow.

## Install (dev)
```bash
pip install -e .